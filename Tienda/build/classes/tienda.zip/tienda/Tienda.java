
package tienda;


public class Tienda {

  
    public static void main(String[] args) {
    
            Manejador manejador;
            manejador = new Manejador();
            manejador.Menu();
    }

    
    
}
