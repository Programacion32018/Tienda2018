package tienda;

import java.util.Scanner;

public class Manejador {

    Scanner sc = new Scanner(System.in);
    ClienteCheque clienteCheque;

    public Manejador() {
        clienteCheque = new ClienteCheque();

    }

    private void ImpresionClienteCheque() {
        System.out.println("1.Cliente pago cheque");
            System.out.println("Nombre:");
            clienteCheque.setNombres(sc.next());
            System.out.println("Apellido:");
            clienteCheque.setApellidos(sc.next());
            System.out.println("Direccion:");
            clienteCheque.setDireccion(sc.next());
            System.out.println("Nit:");
            clienteCheque.setNit(sc.nextInt());
        clienteCheque.ingresarProducto();
        System.out.println("Apagar es: " + clienteCheque.getTotal());
        Menu();
    }

    public void Menu() {
        {

            int op;
            op = 0;
            do {

                System.out.println("Bienvenido al sistema\n\t");
                System.out.println("1.Pago Efectivo\t 2.Pago Credito 3.Pago cheque\t"
                        + "4. Salir");
                op = sc.nextInt();
                if (op == 1) {
                    System.out.println("Cliente Efectivo\n\t");

                } else if (op == 2) {
                    System.out.println("Cliente Credito\n\t");
                } else if (op == 3) {
                    System.out.println("Cliente Cheque\n\t");
                    ImpresionClienteCheque();
                }

            } while (op != 4);

        }

    }


}
